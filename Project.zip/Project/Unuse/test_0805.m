
clc; close all; clear;

sigma = 1;
train_num = 1000;
test_num = 1000;

% 1-D signal generation

f1 = randi([0 10],train_num,1);

n1 = sqrt(sigma) * randn(size(f1));
f1_tr = f1 + n1;

% Normalisation
[input, minI, maxI] = premnmx(f1_tr');

% Target output generation
s = length(f1);

output = zeros(s,11);

for  timer = 1:s
    output(timer,(f1(timer)+1)) = 1;
end

% Network generation
net = newff(input, output', [10 10], {'logsig' 'logsig' 'purelin'}, 'traingdx');
% net = newff(input, output',10);

% Parameters
net.trainparam.goal = 1e-5;
net.trainparam.epochs = 5000;
net.trainparam.lr = 0.005;
net.trainparam.show = 5;
net.trainparam.max_fail = 500;

% Training
net = train(net, input, output');

%%
% Test set generation

t1 = randi([0 10],test_num,1);

n1 = sqrt(sigma) * randn(size(t1));
t1_tr = t1 + n1;

testinput = tramnmx(t1_tr', minI, maxI);

% Simulation
Y = sim(net, testinput);

% Accuracy
[s1, s2] = size(Y);
hitnum = 0;
for timer = 1:s2
    [m,index] = max(Y(:,timer));
    index = index - 1;
    if index == t1(timer)
        hitnum = hitnum + 1;
    end
end

% Accuracy Comparation
t1_nor = round(t1_tr);

flag = 0;
for timer = 1:s2
    if t1_nor(timer) == t1(timer)
        flag = flag + 1;
    end
end

accuracy_nn = hitnum/s2;
accuracy_nor = flag/s2;
